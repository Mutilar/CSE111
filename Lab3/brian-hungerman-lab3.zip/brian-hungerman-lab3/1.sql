SELECT c_address, c_phone 
FROM tcph.customer 
WHERE c_name = 'Customer#000000227'