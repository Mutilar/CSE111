SELECT MAX(DATEDIFF(l_shipdate,l_commitdate))
FROM lineitem